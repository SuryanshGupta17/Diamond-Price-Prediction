A project to demonstrate the creation of ML pipeline

Step 1: Create a virtual environment
```
conda create -p venv python==3.11
```
Step2: Create setup.py

Step3: Create requirements.txt