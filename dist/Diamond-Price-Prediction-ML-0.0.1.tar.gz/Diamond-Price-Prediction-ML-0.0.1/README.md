A project to demonstrate the creation of ML pipeline

Step 1: Create a Virtual environment
...
conda create -p venv python==3.8
...
Step 2: Create setup.py
...
Step 3: Create requirements.txt"

